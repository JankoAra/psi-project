from django.apps import AppConfig


class SlobodnaEnciklopedijaPticaSrbijeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'slobodna_enciklopedija_ptica_srbije'
